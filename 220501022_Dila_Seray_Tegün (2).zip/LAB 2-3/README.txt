  ###        tablo1 ve tablo2 hocalar tarafından doldurulması gereken tablolardır.
  ###        tablo1 ve tablo2 tabloları  oluşturmak için  tablo1_tablo2_create.py dosyasını çalıştırınız.(bir kerelik)
  ###        size gönderilen dosyada hocanın proje dokumanında girdiği değerler sizin yerinize girilmiştir. (size gönderilen bu proje dosyasını açtığınızda tablo1 ve tablo2 tablolarının oluşturulduğunu göreceksiniz)
  ###        Eğer tablo1 ve tablo2 yi değiştirmek isterseniz içini açıp doğrudan çalıştırıp kaydediniz.
  ###        Eğer tablo1 ve tablo2 yi değiştirmek istemezseniz direkt olarak önceden oluşturulan tablo1 ve tablo2yi kullanabilirsiniz.
  ###        Daha sonradan tablo3_tablo4_tablo5_create.py dosyasını çalıştırınız.
  ###        tablo3_tablo4_tablo5_create.py çalıştıktan sonra dosya3 ve her öğrenci için dosya4 ve dosya5 oluşturulacaktır.
  ###        dosyalar düzenli gözükmesi için tablo4'ler tablo4 klasörü altında  tablo5'ler tablo5 klasörü altında oluşturulacaktır.(projeyi ilk çalıştırdığınızda tablo4 ve tablo5 klasörleri boştur dosyayı çalıştırdığınızda  tablolar ilgili alt klasöre oluşturulacaktır.)